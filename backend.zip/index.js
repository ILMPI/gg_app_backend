//reponsible for loading environment variables and starting the server

// Config .env
require('dotenv').config();

// Start the server
require('./server');
